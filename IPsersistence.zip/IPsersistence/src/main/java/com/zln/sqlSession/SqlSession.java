package com.zln.sqlSession;

import java.util.List;

public interface SqlSession {

    public <E> List<E> selectList(String statementId, Object... params) throws Exception;

    public <T> T selectOne(String statementId,Object... params) throws Exception;

    public int updateOne(String statementId,Object... params) throws Exception;

    public int insertOne(String statementId,Object... params) throws Exception;

    public int deleteOne(String statementId,Object... params) throws Exception;

    public <T> T getMapper(Class<?> mapperClass);
}
