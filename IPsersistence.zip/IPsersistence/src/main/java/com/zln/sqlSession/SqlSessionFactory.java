package com.zln.sqlSession;

public interface SqlSessionFactory {

    public SqlSession openSession();
}
